package com.luv2code.springsecurity.demo.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public abstract class SecurityWebApp extends AbstractAnnotationConfigDispatcherServletInitializer {

	

	

}
 